REM License issued by BayesFusion Licensing Server
REM This code must be executed before any other SMILE.NET object is created 
Dim smileLicense As New Smile.License(
	"SMILE LICENSE a7d1f11e f6b98d37 015aebf2 " +
	"THIS IS AN ACADEMIC LICENSE AND CAN BE USED " +
	"SOLELY FOR ACADEMIC RESEARCH AND TEACHING, " +
	"AS DEFINED IN THE BAYESFUSION ACADEMIC " +
	"SOFTWARE LICENSING AGREEMENT. " +
	"Serial #: 2povyo3ulz2nqlu5s6sdvp0z7 " +
	"Issued for: Nicolas Herve Gratius (ngratius@andrew.cmu.edu) " +
	"Academic institution: Carnegie Mellon University " +
	"Valid until: 2025-12-31 " +
	"Research project focusing on BN model development and refinement.",
	{
	&H4d,&Hcf,&Hfa,&H74,&Hb9,&H1b,&Haf,&H4a,&H58,&H1a,&H43,&H40,&H65,&H02,&H81,&H25,
	&Hea,&Hb4,&Hd0,&H30,&H94,&H96,&H15,&H6e,&H1a,&Had,&Hfe,&H16,&H79,&H5e,&Hea,&Hd6,
	&Hc3,&H2e,&H5c,&H31,&H90,&H79,&H4c,&Hab,&Ha1,&H48,&H97,&Hd1,&Hf8,&H04,&Hd7,&H14,
	&H04,&H10,&Hf7,&H26,&Hd3,&H2e,&H05,&H0e,&H36,&H0a,&Hfc,&H9d,&Hed,&H9c,&H84,&Hb8
	})
