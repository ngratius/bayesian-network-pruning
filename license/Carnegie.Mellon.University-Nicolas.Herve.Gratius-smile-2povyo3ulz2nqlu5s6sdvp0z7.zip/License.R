# License issued by BayesFusion Licensing Server
#
# This code must be executed before any other rSMILE object is created 
rSMILE::License(paste(
	"SMILE LICENSE a7d1f11e f6b98d37 015aebf2 ",
	"THIS IS AN ACADEMIC LICENSE AND CAN BE USED ",
	"SOLELY FOR ACADEMIC RESEARCH AND TEACHING, ",
	"AS DEFINED IN THE BAYESFUSION ACADEMIC ",
	"SOFTWARE LICENSING AGREEMENT. ",
	"Serial #: 2povyo3ulz2nqlu5s6sdvp0z7 ",
	"Issued for: Nicolas Herve Gratius (ngratius@andrew.cmu.edu) ",
	"Academic institution: Carnegie Mellon University ",
	"Valid until: 2025-12-31 ",
	"Research project focusing on BN model development and refinement.",
	sep=""),as.integer(c(
	77,-49,-6,116,-71,27,-81,74,88,26,67,64,101,2,-127,37,
	-22,-76,-48,48,-108,-106,21,110,26,-83,-2,22,121,94,-22,-42,
	-61,46,92,49,-112,121,76,-85,-95,72,-105,-47,-8,4,-41,20,
	4,16,-9,38,-45,46,5,14,54,10,-4,-99,-19,-100,-124,-72))
)
